// form 
document.querySelector('form').style["background"] = "#414";
document.querySelector('form').style["display"] = "grid";
document.querySelector('form').style["padding"] = "60vh";
document.querySelector('input').style["color"] = "#000";
document.querySelector('textarea').style["color"] = "black";
// bdd